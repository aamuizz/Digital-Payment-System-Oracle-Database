create trigger REPCATLOGTRIG
  after update or delete
  on REPCAT$_REPCATLOG
  BEGIN
  sys.dbms_alert.signal('repcatlog_alert', '');
END;
/

